datablock fxDTSBrickData (brick3x3fData)
{
	brickFile = "./3x3f.blb";
	category = "Plates";
	subCategory = "3x";
	uiName = "3x3F";
	iconName = "Add-Ons/Brick_DemiansBB3/3x3f";
};

datablock fxDTSBrickData (brick3x4fData)
{
	brickFile = "./3x4f.blb";
	category = "Plates";
	subCategory = "3x";
	uiName = "3x4F";
	iconName = "Add-Ons/Brick_DemiansBB3/3x4f";
};

datablock fxDTSBrickData (brick3x5fData)
{
	brickFile = "./3x5f.blb";
	category = "Plates";
	subCategory = "3x";
	uiName = "3x5F";
	iconName = "Add-Ons/Brick_DemiansBB3/3x5f";
};

datablock fxDTSBrickData (brick3x6fData)
{
	brickFile = "./3x6f.blb";
	category = "Plates";
	subCategory = "3x";
	uiName = "3x6F";
	iconName = "Add-Ons/Brick_DemiansBB3/3x6f";
};

datablock fxDTSBrickData (brick3x8fData)
{
	brickFile = "./3x8f.blb";
	category = "Plates";
	subCategory = "3x";
	uiName = "3x8F";
	iconName = "Add-Ons/Brick_DemiansBB3/3x8f";
};

datablock fxDTSBrickData (brick3x10fData)
{
	brickFile = "./3x10f.blb";
	category = "Plates";
	subCategory = "3x";
	uiName = "3x10F";
	iconName = "Add-Ons/Brick_DemiansBB3/3x10f";
};

datablock fxDTSBrickData (brick3x12fData)
{
	brickFile = "./3x12f.blb";
	category = "Plates";
	subCategory = "3x";
	uiName = "3x12F";
	iconName = "Add-Ons/Brick_DemiansBB3/3x12f";
};

datablock fxDTSBrickData (brick3x14fData)
{
	brickFile = "./3x14f.blb";
	category = "Plates";
	subCategory = "3x";
	uiName = "3x14F";
	iconName = "Add-Ons/Brick_DemiansBB3/3x14f";
};

datablock fxDTSBrickData (brick3x16fData)
{
	brickFile = "./3x16f.blb";
	category = "Plates";
	subCategory = "3x";
	uiName = "3x16F";
	iconName = "Add-Ons/Brick_DemiansBB3/3x16f";
};

datablock fxDTSBrickData (brick3x32fData)
{
	brickFile = "./3x32f.blb";
	category = "Plates";
	subCategory = "3x";
	uiName = "3x32F";
	iconName = "Add-Ons/Brick_DemiansBB3/3x32f";
};

datablock fxDTSBrickData (brick3x3x1Data)
{
	brickFile = "./3x3x1.blb";
	category = "Bricks";
	subCategory = "3x";
	uiName = "3x3x1";
	iconName = "Add-Ons/Brick_DemiansBB3/3x3x1";
};

datablock fxDTSBrickData (brick3x4x1Data)
{
	brickFile = "./3x4x1.blb";
	category = "Bricks";
	subCategory = "3x";
	uiName = "3x4x1";
	iconName = "Add-Ons/Brick_DemiansBB3/3x4x1";
};

datablock fxDTSBrickData (brick3x5x1Data)
{
	brickFile = "./3x5x1.blb";
	category = "Bricks";
	subCategory = "3x";
	uiName = "3x5x1";
	iconName = "Add-Ons/Brick_DemiansBB3/3x5x1";
};

datablock fxDTSBrickData (brick3x6x1Data)
{
	brickFile = "./3x6x1.blb";
	category = "Bricks";
	subCategory = "3x";
	uiName = "3x6x1";
	iconName = "Add-Ons/Brick_DemiansBB3/3x6x1";
};

datablock fxDTSBrickData (brick3x8x1Data)
{
	brickFile = "./3x8x1.blb";
	category = "Bricks";
	subCategory = "3x";
	uiName = "3x8x1";
	iconName = "Add-Ons/Brick_DemiansBB3/3x8x1";
};

datablock fxDTSBrickData (brick3x10x1Data)
{
	brickFile = "./3x10x1.blb";
	category = "Bricks";
	subCategory = "3x";
	uiName = "3x10x1";
	iconName = "Add-Ons/Brick_DemiansBB3/3x10x1";
};

datablock fxDTSBrickData (brick3x12x1Data)
{
	brickFile = "./3x12x1.blb";
	category = "Bricks";
	subCategory = "3x";
	uiName = "3x12x1";
	iconName = "Add-Ons/Brick_DemiansBB3/3x12x1";
};

datablock fxDTSBrickData (brick3x14x1Data)
{
	brickFile = "./3x14x1.blb";
	category = "Bricks";
	subCategory = "3x";
	uiName = "3x14x1";
	iconName = "Add-Ons/Brick_DemiansBB3/3x14x1";
};

datablock fxDTSBrickData (brick3x16x1Data)
{
	brickFile = "./3x16x1.blb";
	category = "Bricks";
	subCategory = "3x";
	uiName = "3x16x1";
	iconName = "Add-Ons/Brick_DemiansBB3/3x16x1";
};

datablock fxDTSBrickData (brick3x32x1Data)
{
	brickFile = "./3x32x1.blb";
	category = "Bricks";
	subCategory = "3x";
	uiName = "3x32x1";
	iconName = "Add-Ons/Brick_DemiansBB3/3x32x1";
};

datablock fxDTSBrickData (brick1x1x3Data)
{
	brickFile = "./1x1x3.blb";
	category = "Bricks";
	subCategory = "3x Height";
	uiName = "1x1x3";
	iconName = "Add-Ons/Brick_DemiansBB3/1x1x3";
};

datablock fxDTSBrickData (brick1x2x3Data)
{
	brickFile = "./1x2x3.blb";
	category = "Bricks";
	subCategory = "3x Height";
	uiName = "1x2x3";
	iconName = "Add-Ons/Brick_DemiansBB3/1x2x3";
};

datablock fxDTSBrickData (brick1x3x3Data)
{
	brickFile = "./1x3x3.blb";
	category = "Bricks";
	subCategory = "3x Height";
	uiName = "1x3x3";
	iconName = "Add-Ons/Brick_DemiansBB3/1x3x3";
};

datablock fxDTSBrickData (brick1x4x3Data)
{
	brickFile = "./1x4x3.blb";
	category = "Bricks";
	subCategory = "3x Height";
	uiName = "1x4x3";
	iconName = "Add-Ons/Brick_DemiansBB3/1x4x3";
};

datablock fxDTSBrickData (brick1x5x3Data)
{
	brickFile = "./1x5x3.blb";
	category = "Bricks";
	subCategory = "3x Height";
	uiName = "1x5x3";
	iconName = "Add-Ons/Brick_DemiansBB3/1x5x3";
};

datablock fxDTSBrickData (brick1x6x3Data)
{
	brickFile = "./1x6x3.blb";
	category = "Bricks";
	subCategory = "3x Height";
	uiName = "1x6x3";
	iconName = "Add-Ons/Brick_DemiansBB3/1x6x3";
};

datablock fxDTSBrickData (brick1x8x3Data)
{
	brickFile = "./1x8x3.blb";
	category = "Bricks";
	subCategory = "3x Height";
	uiName = "1x8x3";
	iconName = "Add-Ons/Brick_DemiansBB3/1x8x3";
};

datablock fxDTSBrickData (brick1x10x3Data)
{
	brickFile = "./1x10x3.blb";
	category = "Bricks";
	subCategory = "3x Height";
	uiName = "1x10x3";
	iconName = "Add-Ons/Brick_DemiansBB3/1x10x3";
};

datablock fxDTSBrickData (brick1x12x3Data)
{
	brickFile = "./1x12x3.blb";
	category = "Bricks";
	subCategory = "3x Height";
	uiName = "1x12x3";
	iconName = "Add-Ons/Brick_DemiansBB3/1x12x3";
};

datablock fxDTSBrickData (brick1x14x3Data)
{
	brickFile = "./1x14x3.blb";
	category = "Bricks";
	subCategory = "3x Height";
	uiName = "1x14x3";
	iconName = "Add-Ons/Brick_DemiansBB3/1x14x3";
};

datablock fxDTSBrickData (brick1x16x3Data)
{
	brickFile = "./1x16x3.blb";
	category = "Bricks";
	subCategory = "3x Height";
	uiName = "1x16x3";
	iconName = "Add-Ons/Brick_DemiansBB3/1x16x3";
};

datablock fxDTSBrickData (brick1x32x3Data)
{
	brickFile = "./1x32x3.blb";
	category = "Bricks";
	subCategory = "3x Height";
	uiName = "1x32x3";
	iconName = "Add-Ons/Brick_DemiansBB3/1x32x3";
};

datablock fxDTSBrickData (brick2x3x3Data)
{
	brickFile = "./2x3x3.blb";
	category = "Bricks";
	subCategory = "3x Height";
	uiName = "2x3x3";
	iconName = "Add-Ons/Brick_DemiansBB3/2x3x3";
};

datablock fxDTSBrickData (brick2x5x3Data)
{
	brickFile = "./2x5x3.blb";
	category = "Bricks";
	subCategory = "3x Height";
	uiName = "2x5x3";
	iconName = "Add-Ons/Brick_DemiansBB3/2x5x3";
};

datablock fxDTSBrickData (brick2x8x3Data)
{
	brickFile = "./2x8x3.blb";
	category = "Bricks";
	subCategory = "3x Height";
	uiName = "2x8x3";
	iconName = "Add-Ons/Brick_DemiansBB3/2x8x3";
};

datablock fxDTSBrickData (brick2x10x3Data)
{
	brickFile = "./2x10x3.blb";
	category = "Bricks";
	subCategory = "3x Height";
	uiName = "2x10x3";
	iconName = "Add-Ons/Brick_DemiansBB3/2x10x3";
};

datablock fxDTSBrickData (brick2x12x3Data)
{
	brickFile = "./2x12x3.blb";
	category = "Bricks";
	subCategory = "3x Height";
	uiName = "2x12x3";
	iconName = "Add-Ons/Brick_DemiansBB3/2x12x3";
};

datablock fxDTSBrickData (brick2x14x3Data)
{
	brickFile = "./2x14x3.blb";
	category = "Bricks";
	subCategory = "3x Height";
	uiName = "2x14x3";
	iconName = "Add-Ons/Brick_DemiansBB3/2x14x3";
};

datablock fxDTSBrickData (brick2x16x3Data)
{
	brickFile = "./2x16x3.blb";
	category = "Bricks";
	subCategory = "3x Height";
	uiName = "2x16x3";
	iconName = "Add-Ons/Brick_DemiansBB3/2x16x3";
};

datablock fxDTSBrickData (brick2x32x3Data)
{
	brickFile = "./2x32x3.blb";
	category = "Bricks";
	subCategory = "3x Height";
	uiName = "2x32x3";
	iconName = "Add-Ons/Brick_DemiansBB3/2x32x3";
};