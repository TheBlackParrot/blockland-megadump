// preventing mishaps with file sorting
if(isFile("Add-Ons/Gamemode_Boulder_Dash/RequiredAddons/Event_Zones.zip")) {
	exec("Add-Ons/Gamemode_Boulder_Dash/RequiredAddons/Event_Zones/server.cs");
}


%errorA = ForceRequiredAddOn("Brick_Large_Cubes");





if(%errorA == $Error::AddOn_NotFound)
   error("ERROR: Brick_Zones - required add-on Brick_Large_Cubes not found");
else
   exec("./Bricks.cs"); 