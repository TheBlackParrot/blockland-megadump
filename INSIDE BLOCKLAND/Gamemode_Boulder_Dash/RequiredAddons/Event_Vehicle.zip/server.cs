registerInputEvent(fxDtsBrick,"onVehicleEnter","Self fxDtsBrick\tPlayer Player\tClient GameConnection\tMinigame Minigame\tVehicle Vehicle");
registerInputEvent(fxDtsBrick,"onVehicleLeave","Self fxDtsBrick\tPlayer Player\tClient GameConnection\tMinigame Minigame\tVehicle Vehicle");
registerInputEvent(fxDtsBrick,"onVehicleDeath","Self fxDtsBrick\tPlayer Player\tClient GameConnection\tMinigame Minigame");
registerInputEvent(fxDtsBrick,"onVehicleSpawn","Self fxDtsBrick\tMinigame Minigame\tVehicle Vehicle");
registerOutputEvent(Vehicle,"respawn","",1);
registerOutputEvent(Vehicle,"destroy","",1);
registerOutputEvent(Vehicle,"addHealth","int -10000 10000 25",1);
registerOutputEvent(Vehicle,"setHealth","int 0 10000 200",1);
registerOutputEvent(Vehicle,"setVelocity","vector 200",0);
registerOutputEvent(Vehicle,"addVelocity","vector 200",0);
registerOutputEvent(Vehicle,"setVehicleScale","float 0.2 2 0.1 1",1);
registerOutputEvent(Vehicle,"setColor","paintColor 1",1);
registerOutputEvent(Vehicle,"setShapeName","string 25 50",0);
registerOutputEvent(Vehicle,"setShapeNameColor","paintColor 1",0);
registerOutputEvent(Vehicle,"setShapeNameDistance","int 0 3000 300",0);
registerOutputEvent(Vehicle,"unMountDriver","",1);
registerOutputEvent(Vehicle,"unMountPlayer","int 1 32 1\tbool",1);
registerOutputEvent(Vehicle,"toggleWheel","int 1 12 1\tbool",1);
registerOutputEvent(Vehicle,"spawnExplosion","dataBlock ProjectileData\tfloat 0.2 2 0.1 1",1);
registerOutputEvent(Vehicle,"spawnProjectile","int -100 100 10\tdataBlock ProjectileData\tvector 200\tfloat 0.2 2 0.1 1",1);
package Event_Vehicle
{
	function Armor::onMount(%this,%player,%obj,%a,%b,%c,%d,%e,%f)
	{
		Parent::onMount(%this,%player,%obj,%a,%b,%c,%d,%e,%f);
		if(isObject(%obj.spawnBrick) && isObject(%player.client) && %obj.getDatablock().rideable)
		{
			$inputTarget_Self = %obj.spawnBrick;
			$inputTarget_Player = %player;
			$inputTarget_Client = %player.client;
			$inputTarget_Minigame = getMinigameFromObject(%obj.spawnBrick);
			$inputTarget_Vehicle = %obj;
			%obj.spawnBrick.processInputEvent("onVehicleEnter",%player.client);
		}
	}
	function Armor::onUnMount(%this,%player,%obj,%a,%b,%c,%d,%e,%f)
	{
		Parent::onUnMount(%this,%player,%obj,%a,%b,%c,%d,%e,%f);
		if(isObject(%obj.spawnBrick) && isObject(%player.client) && %obj.getDatablock().rideable)
		{
			$inputTarget_Self = %obj.spawnBrick;
			$inputTarget_Player = %player;
			$inputTarget_Client = %player.client;
			$inputTarget_Minigame = getMinigameFromObject(%obj.spawnBrick);
			$inputTarget_Vehicle = %obj;
			%obj.spawnBrick.processInputEvent("onVehicleLeave",%player.client);
		}
	}
	function fxDtsBrick::spawnVehicle(%brick,%vehicle)
	{
		%val = Parent::spawnVehicle(%brick,%vehicle);
		if(isObject(%brick.vehicle))
		{
			$inputTarget_Self = %brick;
			$inputTarget_Minigame = getMinigameFromObject(%brick);
			$inputTarget_Vehicle = %brick.vehicle;
			%brick.processInputEvent("onVehicleSpawn",%brick.respawnTriggeringClient);
		}
		return %val;
	}
	function Vehicle::damage(%vehicle,%source,%pos,%damage,%type)
	{
		if(%vehicle.getDamageLevel() + %damage >= %vehicle.getDatablock().maxDamage)
		{
			if(isObject(%vehicle.spawnBrick) && !%vehicle.triggeredOnDeath)
			{
				%vehicle.triggeredOnDeath = 1;
				%vehicle.spawnBrick.respawnTriggeringClient = %source.client;
				$inputTarget_Self = %vehicle.spawnBrick;
				$inputTarget_Player = %source.client.player;
				$inputTarget_Client = %source.client;
				$inputTarget_Minigame = getMinigameFromObject(%vehicle.spawnBrick.getGroup());
				%vehicle.spawnBrick.processInputEvent("onVehicleDeath",%vehicle.spawnBrick.respawnTriggeringClient);
			}
		}
		Parent::damage(%vehicle,%source,%pos,%damage,%type);
	}
	function serverCmdVehicleSpawn_Respawn(%client)
	{
		%client.wrenchBrick.respawnTriggeringClient = %client;
		Parent::serverCmdVehicleSpawn_Respawn(%client);
	}
	function fxDtsBrick::respawnVehicle(%brick,%client)
	{
		%brick.respawnTriggeringClient = %client;
		Parent::respawnVehicle(%brick,%client);
	}
	function Vehicle::respawn(%vehicle,%client)
	{
		if(isObject(%vehicle.spawnBrick))
		{
			%vehicle.spawnBrick.respawnVehicle(%client);
		}
	}
	function Vehicle::setShapeNameColor(%vehicle,%color,%client)
	{
		if(getWordCount(%color) == 1)
		{
			Parent::setShapeNameColor(%vehicle,getColorIDTable(%color));
		}
		else
		{
			Parent::setShapeNameColor(%vehicle,%color);
		}
	}
	function Vehicle::setColor(%vehicle,%color,%client)
	{
		%vehicle.setNodeColor("ALL",setWord(getColorIDTable(%color),3,1.0));
		if(isObject(%vehicle.turret))
		{
			%vehicle.turret.setNodeColor("ALL",setWord(getColorIDTable(%color),3,1.0));
		}
	}
	function Vehicle::destroy(%vehicle,%client)
	{
		%vehicle.damage(%client.player,%vehicle.getWorldBoxCenter(),%vehicle.getDataBlock().maxDamage);
	}
	function Vehicle::setHealth(%vehicle,%amount,%client)
	{
		if(%amount >  %vehicle.getDatablock().maxDamage)
		{
			%amount = %vehicle.getDatablock().maxDamage;
		}
		if(%amount <= 0)
		{
			%vehicle.damage(%client.player,%vehicle.getWorldBoxCenter(),%vehicle.getDataBlock().maxDamage);
		}
		%damage = %vehicle.getDatablock().maxDamage - %amount;
		%vehicle.setDamageLevel(%damage);
	}
	function Vehicle::addHealth(%vehicle,%amount,%client)
	{
		if(%vehicle.getDamageLevel() - %amount >= %vehicle.getDatablock().maxDamage)
		{
			%vehicle.damage(%client.player,%vehicle.getWorldBoxCenter(),%vehicle.getDataBlock().maxDamage);
			return;
		}
		%vehicle.setDamageLevel(%vehicle.getDamageLevel() - %amount);
	}
	function Vehicle::setVehicleScale(%vehicle,%scale,%client)
	{
		%scale = %scale SPC %scale SPC %scale;
		%vehicle.setScale(%scale);
		if(isObject(%vehicle.turret))
		{
			%vehicle.turret.setScale(%scale);
		}
	}
	function Vehicle::unMountDriver(%vehicle,%client)
	{
		%driver = %vehicle.getControllingObject();
		if(isObject(%driver))
		{
			%driver.getDatablock().doDismount(%driver);
		}
	}
	function Vehicle::unMountPlayer(%vehicle,%slot,%all,%client)
	{
		%slot -= 1;
		if(%all)
		{
			for(%i=0;%i<%vehicle.getDatablock().numMountPoints;%i++)
			{
				%player = %vehicle.getMountedObject(%i);
				if(isObject(%player) && %player.getClassName() $= "Player")
				{
					%player.getDatablock().doDismount(%player);
				}
			}
		}
		else
		{
			%player = %vehicle.getMountedObject(%slot);
			if(isObject(%player) && %player.getClassName() $= "Player")
			{
				%player.getDatablock().doDismount(%player);
			}
		}
	}
	function Vehicle::toggleWheel(%vehicle,%slot,%mode,%client)
	{
		%slot -= 1;
		if(%slot < %vehicle.getDatablock().numWheels)
		{
			if(%mode)
			{
				%vehicle.setWheelTire(%slot,%vehicle.getDatablock().defaultTire);
			}
			else
			{
				%vehicle.setWheelTire(%slot,nothingTire);
			}
		}
	}
	function Vehicle::spawnExplosion(%vehicle,%data,%scale,%client)
	{
		new Projectile()
		{
			dataBlock = %data;
			initialPosition = %vehicle.getWorldBoxCenter();
			initialVelocity = "0 0 0";
			sourceObject = %vehicle;
			sourceSlot = 0;
			client = %client;
			scale = %scale SPC %scale SPC %scale;
		}.explode();
	}
	function Vehicle::spawnProjectile(%vehicle,%initial,%data,%random,%scale,%client)
	{
		%init = vectorScale(%vehicle.getForwardVector(),%initial);
		%init = getWord(%init,0) + getRandom(0,getWord(%random,0)) SPC getWord(%init,1) + getRandom(0,getWord(%random,1)) SPC getWord(%init,2) + getRandom(0,getWord(%random,2));
		new Projectile()
		{
			dataBlock = %data;
			initialPosition = %vehicle.getWorldBoxCenter();
			initialVelocity = %init;
			sourceObject = %vehicle;
			sourceSlot = 0;
			client = %client;
			scale = %scale SPC %scale SPC %scale;
		};
	}
	function Vehicle::addVelocity(%vehicle,%velocity)
	{
		%vehicle.setVelocity(vectorAdd(%vehicle.getVelocity(),%velocity));
	}
};
activatePackage(Event_Vehicle);
if(isFile("Add-Ons/Event_Variables/changelog.txt") && $AddOn__Event_Variables)
{
	registerSpecialVar(Player,"isPassenger","(%this.getObjectMount().dataBlock.rideable)");
	registerSpecialVar(Player,"isDriver","(%this.getObjectMount().dataBlock.rideable && %this.getObjectMount().getControllingObject() == %this)");
}