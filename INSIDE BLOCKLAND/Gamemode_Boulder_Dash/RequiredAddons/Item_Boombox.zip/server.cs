function serverCmdBoombox(%client)
{
	%player = %client.player;
	if(isObject(%player) == false)
	{
		return;
	}
	if(!isObject(%player.stereoHandler))
	{
		%player.stereoHandler = new fxDTSBrick()
		{
			client = %client;
			dataBlock = brickMusicData;
			isPlanted = true;
			isStereo = true;
			mount = %player;
			position = "-10000 -10000 -10000";
		};
	}
	%client.wrenchBrick = %player.stereoHandler;
	%client.wrenchBrick.sendWrenchSoundData(%client);
	commandToClient(%client,'openWrenchSoundDlg',"Boombox",1);
}

package Boombox
{
	function serverCmdSetWrenchData(%client, %data)
	{
		if(%client.wrenchBrick.isStereo)
		{
			if(isObject(%client.wrenchBrick.mount))
			{
				if(getWord(getField(%data,1),1) $= "0")
				{
					%client.wrenchBrick.mount.stopAudio(0);
				}
				else
				{
					%client.wrenchBrick.mount.playAudio(0,getWord(getField(%data,1),1));
				}
			}
		}
		else
		{
			Parent::serverCmdSetWrenchData(%client,%data);
		}
	}
	
	function Player::delete(%this)
	{
		if(isObject(%this.stereoHandler))
		{
			%this.stereoHandler.delete();
		}
		Parent::delete(%this);
	}
};
activatePackage(Boombox);