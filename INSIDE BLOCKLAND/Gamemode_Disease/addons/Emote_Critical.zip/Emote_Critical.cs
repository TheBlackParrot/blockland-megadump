datablock AudioProfile(CritHitSound)
{
	filename = "./crit_hit.wav";
	description = AudioClose3d;
	preload = true;
};

datablock AudioProfile(CritRecieveSound)
{
	filename = "./crit_received.wav";
	description = AudioClosest3d;
	preload = true;
};

datablock AudioDescription(AudioClosestQuiet3d : AudioClosest3d)
{
	volume = 0.75;
};

datablock AudioProfile(CritFireSound)
{
	filename = "./crit_fire.wav";
	description = AudioClosestQuiet3d;
	preload = true;
};

datablock ParticleData(CritParticle)
{
   dragCoefficient      = 5.0;
   gravityCoefficient   = 0.0;
   inheritedVelFactor   = 0.0;
   windCoefficient      = 0;
   constantAcceleration = 0.0;
   lifetimeMS           = 500;
   lifetimeVarianceMS   = 0;
   useInvAlpha          = false;
   textureName          = "./critical";
   colors[0]     = "0 1 0 1";
   colors[1]     = "1 0 0 1";
   colors[2]     = "1 0 0 0";
   sizes[0]      = 1.5;
   sizes[1]      = 1.5;
   sizes[2]      = 1.4;
   times[0]      = 0.0;
   times[1]      = 0.6;
   times[2]      = 1.0;
};

datablock ParticleEmitterData(CritEmitter)
{
   ejectionPeriodMS = 35;
   periodVarianceMS = 0;
   ejectionVelocity = 0.0;
   ejectionOffset   = 1.8;
   velocityVariance = 0.0;
   thetaMin         = 0;
   thetaMax         = 0;
   phiReferenceVel  = 0;
   phiVariance      = 0;
   overrideAdvance = false;
   lifeTimeMS = 100;
   particles = "CritParticle";

   doFalloff = false; //if we do fall off with this emitter it ends up flickering, for most emitters you want this TRUE

   emitterNode = GenericEmitterNode;        //used when placed on a brick
   pointEmitterNode = TenthEmitterNode; //used when placed on a 1x1 brick

   uiName = "Emote - Critical Hit";
};

datablock ExplosionData(CritExplosion)
{
   lifeTimeMS = 2000;
   emitter[0] = CritEmitter;
   soundProfile = "";
};

//we cant spawn explosions, so this is a workaround for now
datablock ProjectileData(CritProjectile)
{
   explosion           = CritExplosion;

   armingDelay         = 0;
   lifetime            = 10;
   explodeOnDeath		= true;

   uiName = "Critical Hit Emote";
};