datablock AudioProfile(CityHeliFlySound)
{
   filename    = "./civheli1.wav";
   description = AudioDefaultLooping3d;
   preload = true;
};

datablock FlyingVehicleData(CityHeliLrgVehicle)
{
   //Tagged fields for mission editor
      category = "Vehicles";
      displayName = " ";

   //Shapebase Fields
      shapeFile   = "./CityHeliLrg.dts";  
      emap        = true;
      mass        = 400;
      drag        = 1;
      density     = 0.7;
      
      maxDamage = 240.00;
      destroyedLevel = 240.00;
      energyPerDamagePoint = 160;
      speedDamageScale = 1.04;
      collDamageThresholdVel = 20.0;
      collDamageMultiplier   = 0.02;

   //Tagged fields for mounting
      minMountDist = 3;   

      numMountPoints = 8;
      mountThread[0] = "sit";
      mountThread[1] = "sit";
      mountThread[2] = "sit";
      mountThread[3] = "sit";
      mountThread[4] = "sit";
      mountThread[5] = "sit";
      mountThread[6] = "sit";
      mountThread[7] = "sit";

		lookUpLimit = 0.5;
		lookDownLimit = 0.5;

   //Vehicle Fields:
      jetForce          = 10000;
      jetEnergyDrain    = 8;
      minJetEnergy      = 10000;

      massCenter        = "0 0 0";
      //massBox           = "1 1 1";
	bodyFriction = 0.9;
	bodyRestitution = 0.1;
	minImpactSpeed = 10;        // Impacts over this invoke the script callback
	softImpactSpeed = 10;       // Play SoftImpact Sound
	hardImpactSpeed = 15;      // Play HardImpact Sound
	groundImpactMinSpeed    = 10.0;
      minRollSpeed      = 0;
      maxSteeringAngle  = 0.785;

      maxDrag        = 40;
      minDrag        = 50;
      integration    = 4;
      collisionTol   = 0.1;
      contactTol     = 0.1;

      cameraRoll     = false;
      cameraMaxDist  = 20;        
      cameraLag      = 0.0;
      cameraDecay    = 0.0;
      cameraOffset   = 5.5;
      cameraTilt     = 0.0;

      //dustEmitter       = ; //ParticleEmitterData
      triggerDustHeight = 3.0;
      dustHeight        = 1.0;

      numDmgEmitterAreas   = 0;
      
      damageEmitter[0] = vehicleBurnEmitter;
      damageEmitterOffset[0] = "0.0 0.0 0.0 ";
      damageLevelTolerance[0] = 0.99;

      damageEmitter[1] = vehicleBurnEmitter;
      damageEmitterOffset[1] = "0.0 0.0 0.0 ";
      damageLevelTolerance[1] = 1.0;

      //splashEmitter[0]        = ; //ParticleEmitterData

      splashFreqMod     = 300.0;
      splashVelEpsilon  = 0.50;

      exitSplashSoundVelocity    = 2.0;
      softSplashSoundVelocity    = 1.0;
      mediumSplashSoundVelocity  = 2.0;
      hardSplashSoundVelocity    = 3.0;

      collDamageThresholdVel  = 20;
      collDamageMultiplier    = 0.05;

   //For Wrench Gui
      uiName   = "Civ Heli Large";
      rideAble = true;
      paintable = true;
		
   //Flying vehicle fields
      //jetSound = ;      //AudioProfile
      //engineSound = ;   //AudioProfile
  maneuveringForce = 3100;
  horizontalSurfaceForce = 10;
  verticalSurfaceForce = 1300;
  autoInputDamping = 0.95;
  steeringForce = 1000;
  steeringRollForce = -20;
  rollForce = 1;
  autoAngularForce = 1000;
  rotationalDrag = 8;
  autoLinearForce = 100;
  maxAutoSpeed = 15;
  hoverHeight = 0.5;
  createHoverHeight = 0.25;

      minTrailSpeed        = 1;
      vertThrustMultiple   = 1.0;

   
   //Tagged fields for damage
      initialExplosionProjectile = CityHeliLrgExplosionProjectile;
      initialExplosionOffset = 0;         //offset only uses a z value for now

      burnTime = 500;

      finalExplosionProjectile = CityHeliLrgFinalExplosionProjectile;
      finalExplosionOffset = 0.5;          //offset only uses a z value for now

      minRunOverSpeed    = 5;   //how fast you need to be going to run someone over (do damage)
      runOverDamageScale = 5;   //when you run over someone, speed * runoverdamagescale = damage amt
      runOverPushScale   = 1.2; //how hard a person you're running over gets pushed


	//Heighcontrol parameters
	heightcontrol= 1;		//Enables the heightcontrol support for this vehicle
	ascendVelocity= 3.00;	//The velocity it adds when a user presses/holds the jumpkey
	descendVelocity= -1.25;	//The velocity it extracts when a user presses/holds the jumpkey
   
};
datablock DebrisData(CityHeliLrgDebris)
{
   emitters = "jeepDebrisTrailEmitter";

	shapeFile = "./CityHeliLrgDebris.dts";
	lifetime = 5.0;
	minSpinSpeed = -300.0;
	maxSpinSpeed = 300.0;
	elasticity = 1.5;
	friction = 0.2;
	numBounces = 1;
	staticOnMaxBounce = true;
	snapOnMaxBounce = false;
	fade = true;

	gravModifier = 3;
};
datablock ExplosionData(CityHeliLrgFinalExplosion)
{
   //explosionShape = "";
   lifeTimeMS = 8000;

   soundProfile = vehicleExplosionSound;
   
   emitter[0] = vehicleFinalExplosionEmitter3;
   emitter[1] = vehicleFinalExplosionEmitter2;

   particleEmitter = vehicleFinalExplosionEmitter;
   particleDensity = 20;
   particleRadius = 1.0;

   debris = CityHeliLrgDebris;
   debrisNum = 1;
   debrisNumVariance = 0;
   debrisPhiMin = 0;
   debrisPhiMax = 360;
   debrisThetaMin = 0;
   debrisThetaMax = 50;
   debrisVelocity = 15;
   debrisVelocityVariance = 3;

   faceViewer     = true;
   explosionScale = "1 1 1";

   shakeCamera = true;
   camShakeFreq = "7.0 8.0 7.0";
   camShakeAmp = "10.0 10.0 10.0";
   camShakeDuration = 0.75;
   camShakeRadius = 15.0;

   // Dynamic light
   lightStartRadius = 0;
   lightEndRadius = 20;
   lightStartColor = "0.45 0.3 0.1";
   lightEndColor = "0 0 0";

   //impulse
   impulseRadius = 15;
   impulseForce = 1000;
   impulseVertical = 2000;

   //radius damage
   radiusDamage        = 30;
   damageRadius        = 8.0;

   //burn the players?
   playerBurnTime = 5000;

};

datablock ProjectileData(CityHeliLrgFinalExplosionProjectile)
{
   directDamage        = 0;
   radiusDamage        = 0;
   damageRadius        = 0;
   explosion           = CityHeliLrgFinalExplosion;

   directDamageType  = $DamageType::jeepExplosion;
   radiusDamageType  = $DamageType::jeepExplosion;

   explodeOnDeath		= 1;

   armingDelay         = 0;
   lifetime            = 10;
};

function CityHeliLrgvehicle::onadd(%this,%obj)
{ 
	   %obj.playThread(0,"propfast");
         	%obj.playAudio(0, CityHeliFlySound);
}