datablock AudioProfile(KnifeFireSound)
{
   filename    = "./knife_swing.wav";
   description = AudioClose3d;
   preload = true;
};

datablock AudioProfile(CombatKnifeHitSoundA)
{
   filename    = "./melee_knife_02.wav";
   description = AudioClose3d;
   preload = true;
};
datablock AudioProfile(CombatKnifeHitSoundB)
{
   filename    = "./melee_knife_01.wav";
   description = AudioClose3d;
   preload = true;
};

datablock ParticleData(combatKnifeParticle)
{
	dragCoefficient      = 5;
	gravityCoefficient   = 0;
	inheritedVelFactor   = 0.2;
	constantAcceleration = 0.0;
	lifetimeMS           = 100;
	lifetimeVarianceMS   = 0;
	textureName          = "base/data/particles/cloud";
	spinSpeed		= 10.0;
	spinRandomMin		= -500.0;
	spinRandomMax		= 500.0;

   colors[0]     = "0.5 0.5 0.5 0.2";
	colors[1]     = "0.5 0.5 0.7 0.2";
	colors[2]     = "0.5 0.5 0.7 0.0";

	sizes[0]      = 0.15;
   sizes[1]      = 0.12;
	sizes[2]      = 0.1;

   times[0] = 0.0;
   times[1] = 0.2;
   times[2] = 1.0;

	useInvAlpha = false;
};
datablock ParticleEmitterData(combatKnifeEmitter)
{
   ejectionPeriodMS = 1;
   periodVarianceMS = 0;
   ejectionVelocity = 0.01;
   velocityVariance = 0.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 25;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "combatKnifeParticle";

   uiName = "Combat Knife Swipe";
};
//////////
// item //
//////////
datablock ItemData(CombatKnifeItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "./bowie_knife.dts";
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Combat Knife";
	iconName = "./combatknife";
	doColorShift = true;
	colorShiftColor = "0.6 0.6 0.6 1.000";

	 // Dynamic properties defined by the scripts
	l4ditemtype = "secondary";
	image = CombatKnifeImage;
	canDrop = true;
};

////////////////
//weapon image//
////////////////

AddDamageType("CombatKnife",   '<bitmap:Add-Ons/Gamemode_Disease/addons/Weapon_Melee_Extended/knife1_ci> %1',    '%2 <bitmap:Add-Ons/Gamemode_Disease/addons/Weapon_Melee_Extended/knife1_ci> %1',0.75,1);

datablock ShapeBaseImageData(CombatKnifeImage)
{
	shapeFile = "./bowie_knife.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0.0 0 0.0";
   rotation = eulerToMatrix("0 0 0");
   eyeOffset = "0";

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.  
   correctMuzzleVector = false;

   className = "TF2MeleeWeaponImage";

   // Projectile && Ammo.
   item = CombatKnifeItem;
   ammo = " ";
   projectile = hammerProjectile;
   projectileType = Projectile;

   //melee particles shoot from eye node for consistancy
   melee = true;
   doRetraction = false;
   //raise your arm up or not
   armReady = true;

   //casing = " ";
   doColorShift = true;
   colorShiftColor = CombatKnifeItem.colorShiftColor;
   
   raycastWeaponRange = 3;
   raycastWeaponTargets = $TypeMasks::FxBrickObjectType |	//Targets the weapon can hit: Raycasting Bricks
   				$TypeMasks::PlayerObjectType |	//AI/Players
   				$TypeMasks::StaticObjectType |	//Static Shapes
   				$TypeMasks::TerrainObjectType |	//Terrain
   				$TypeMasks::VehicleObjectType;	//Vehicles
   raycastExplosionProjectile = hammerProjectile;
   raycastExplosionBrickSound = combatknifeHitSoundA;
   raycastExplosionPlayerSound = combatknifeHitSoundB;
   raycastDirectDamage = 105;
   raycastDirectDamageType = $DamageType::CombatKnife;
   
   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state
	stateName[0]			= "Activate";
	stateTimeoutValue[0]		= 0.2;
	stateTransitionOnTimeout[0]	= "StabCooldown";
	stateSequence[0]		= "Activate";
	stateSound[0]					= weaponSwitchSound;

	stateName[1]			= "Ready";
	stateTransitionOnTriggerDown[1]	= "Charge";
	stateScript[1]                  = "onReady";
	stateAllowImageChange[1]	= true;
	
	stateName[2]                    = "Charge";
	stateTransitionOnTimeout[2]	= "Armed";
	stateTimeoutValue[2]            = 0.4;
	stateWaitForTimeout[2]		= false;
	stateTransitionOnTriggerUp[2]	= "AbortCharge";
	stateSequence[2]		= "Prime";
	stateScript[2]                  = "onCharge";
	stateAllowImageChange[2]        = false;
	
	stateName[3]			= "AbortCharge";
	stateTransitionOnTimeout[3]	= "StabCooldown";
	stateTimeoutValue[3]		= 0.1;
	stateWaitForTimeout[3]		= true;
	stateEmitterNode[3]			= "tipNode";
	stateSequence[3]		= "Swing";
	stateEmitter[3]			= combatKnifeEmitter;
	stateEmitterTime[3]			= 0.17;
	stateScript[3]			= "onStabfire";
	stateSound[3]				= knifeFireSound;
	stateAllowImageChange[3]	= false;

	stateName[4]			= "Armed";
	stateTransitionOnTriggerUp[4]	= "Fire";
	stateAllowImageChange[4]	= false;
	stateScript[4]                  = "onCharge";

	stateName[5]			= "Fire";
	stateTransitionOnTimeout[5]	= "Stabcooldown";
	stateTimeoutValue[5]		= 0.4;
	stateEmitter[5]			= combatKnifeEmitter;
	stateEmitterTime[5]			= 0.289;
	stateEmitterNode[5]			= "tipNode";
	stateFire[5]			= true;
	stateSequence[5]		= "swipe";
	stateScript[5]			= "onFire";
	stateWaitForTimeout[5]		= true;
	stateAllowImageChange[5]	= false;
	stateSound[5]				= knifeFireSound;

	stateName[6]			= "StabCooldown";
	stateTransitionOnTimeout[6]	= "Ready";
	stateTimeoutValue[6]		= 0.1;
	stateWaitForTimeout[6]		= true;
	stateSequence[6]		= "Prime";
	stateAllowImageChange[6]	= false;
};

function CombatKnifeImage::onFire(%this, %obj, %slot)
{
	%obj.playThread(2,shiftto);
	%obj.playThread(3,spearthrow);
	%obj.playThread(4,shiftdown);
	%obj.playThread(5,shiftdown);
	%obj.playThread(6,shiftdown);


	if(getRandom(0,1))
	{
		%this.raycastExplosionBrickSound = CombatKnifeHitSoundA;
		%this.raycastExplosionPlayerSound =meleeSlashSound;
		%this.raycastDirectDamage = 105;
	}
	else
	{
		%this.raycastExplosionBrickSound = CombatKnifeHitSoundB;
		%this.raycastExplosionPlayerSound =meleeSlashSound;
		%this.raycastDirectDamage = 105;
	}

	WeaponImage::onFire(%this, %obj, %slot);
}

function CombatKnifeImage::onStabFire(%this, %obj, %slot)
{
	%obj.playThread(2,shiftto);
	%obj.playThread(3,shiftdown);

	if(getRandom(0,1))
	{
		%this.raycastExplosionBrickSound = CombatKnifeHitSoundA;
		%this.raycastExplosionPlayerSound =meleeSlashSound;
		%this.raycastDirectDamage = 55;
	}
	else
	{
		%this.raycastExplosionBrickSound = CombatKnifeHitSoundB;
		%this.raycastExplosionPlayerSound =meleeSlashSound;
		%this.raycastDirectDamage = 55;
	}

	WeaponImage::onFire(%this, %obj, %slot);
}

function CombatKnifeImage::onFireB(%this, %obj, %slot)
{
	//%obj.playthread(2, shiftaway);
}

function CombatKnifeImage::onActivate(%this, %obj, %slot)
{
	%obj.playthread(2, plant);
}

function CombatKnifeImage::onAbortcharge(%this, %obj, %slot)
{
	%obj.playthread(2, plant);
	%obj.playThread(3,shiftto);
}

function CombatKnifeImage::onCharge(%this, %obj, %slot)
{
	%obj.playthread(2, plant);
}

function CombatKnifeImage::onUnMount(%this,%obj,%slot)
{
	Parent::onMount(%this,%obj,%slot);	
		%obj.playThread(0, root);
}
