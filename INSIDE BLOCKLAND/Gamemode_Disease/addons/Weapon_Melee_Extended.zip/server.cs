
   exec("./Support_RaycastingWeapons.cs");
   exec("./Support_tf2basicmelee.cs");
   exec("./Weapon_L4BGuitar.cs");
   exec("./Weapon_L4BFryingPan.cs");
   exec("./Weapon_L4BMachete.cs");
   exec("./Weapon_L4BBaton.cs");
   exec("./Weapon_L4BKatana.cs");
   exec("./Weapon_L4BCrowbar.cs");
   exec("./Weapon_L4BSpade.cs");
   exec("./Weapon_Combatknife.cs");
   exec("./Weapon_Pipe.cs");
   exec("./Weapon_Ice_axe.cs");
   exec("./Weapon_Sledgehammer.cs");

datablock AudioProfile(meleeSlashSound)
{
	filename    = "./melee_cut1.wav";
	description = AudioClose3d;
	preload = true;
};

datablock AudioProfile(meleeHammerSound)
{
	filename    = "./melee_blunt.wav";
	description = AudioClose3d;
	preload = true;
};

