
datablock ItemData(ammoDroppedItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system
	shapeFile = "./ammo_player_drop.dts";
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;
	rotate = true;
	uiName = "";
	doColorShift = false;
	colorShiftColor = "0.471 0.471 0.471 1.000";
	canDrop = true;
};
package BigAmmoPackage
{
	function gameConnection::onDeath(%client, %killerPlayer, %killer, %damageType, %unknownA)
	{
		if($Pref::Server::TT1Drop == 1)
		{
		%pos = %client.player.getPosition();
		%posX = getWord(%pos,0);
		%posY = getWord(%pos,1);
		%posZ = getWord(%pos,2) + 1;

		%vec = %client.player.getVelocity();
		%vecX = getWord(%vec,0);
		%vecY = getWord(%vec,1);
		%vecZ = getWord(%vec,2);
			%i = new Item()
			{
				minigame = %client.minigame;
				datablock = ammoDroppedItem;
				canPickup = true;

				position = getword(%pos,0) SPC getword(%pos,1) SPC getword(%pos,2)+1;
			};
			%itemvec = vectorAdd(%vec,getRandom(-8,8) SPC getRandom(-8,8) SPC 4);
			%i.schedule(12000 - 500, fadeout);
			%i.schedule(12000, delete);
			%i.setVelocity(%itemVec);

				%i.pistolcount = %client.quantity["9mmrounds"];
				%i.lrCount = %client.quantity["556rounds"];
				%i.shotguncount = %client.quantity["shotgunrounds"];
				%i.srcount = %client.quantity["308rounds"];
				%i.hrcount = %client.quantity["708rounds"];
				%i.magnumcount = %client.quantity["880rounds"];
				%i.bombcount = %client.quantity["bombrounds"];
				%i.rocketcount = %client.quantity["rocketrounds"];
				%i.boltcount = %client.quantity["boltrounds"];

			MissionCleanup.add(%i);
		}
		parent::onDeath(%client, %killerPlayer, %killer, %damageType, %unknownA);
		}
};
activatePackage(bigAmmoPackage);

function ammoDroppedItem::onAdd(%this, %obj)
{
	%obj.canPickup = true;

	%obj.rotate = true;
	Parent::onAdd(%this, %obj);
}

package BigAmmoDropPackage
{
	function Armor::onCollision(%this, %obj, %col, %a, %b, %c, %d, %e, %f)
	{
	if(%col.dataBlock $= "ammoDroppedItem" && %col.canPickup && %obj.getDamagePercent() < 1.0 && minigameCanUse(%obj.client, %col))
	{
	%obj.client.quantity["9MMrounds"] += %col.pistolCount;
	%obj.client.quantity["556rounds"] += %col.lrCount;
	%obj.client.quantity["shotgunrounds"] += %col.shotgunCount;

	%obj.client.quantity["308rounds"] += %col.srCount;
	%obj.client.quantity["708rounds"] += %col.hrCount;
	%obj.client.quantity["880rounds"] += %col.magnumCount;

	%obj.client.quantity["bombrounds"] += %col.bombCount;
	%obj.client.quantity["rocketrounds"] += %col.rocketCount;
	%obj.client.quantity["boltrounds"] += %col.boltCount;

	if (%obj.client.quantity["9MMrounds"] > $Pref::Server::TT1Max){%obj.client.quantity["9MMrounds"] = $Pref::Server::TT1Max;}
	if (%obj.client.quantity["556rounds"] > $Pref::Server::TT2Max){%obj.client.quantity["556rounds"] = $Pref::Server::TT2Max;}
	if (%obj.client.quantity["shotgunrounds"] > $Pref::Server::TT3Max){%obj.client.quantity["shotgunrounds"] = $Pref::Server::TT3Max;}

	if (%obj.client.quantity["308rounds"] > $Pref::Server::TT4Max){%obj.client.quantity["308rounds"] = $Pref::Server::TT4Max;}
	if (%obj.client.quantity["708rounds"] > $Pref::Server::TT5Max){%obj.client.quantity["708rounds"] = $Pref::Server::TT5Max;}
	if (%obj.client.quantity["880rounds"] > $Pref::Server::TT6Max){%obj.client.quantity["880rounds"] = $Pref::Server::TT6Max;}

	if (%obj.client.quantity["bombrounds"] > $Pref::Server::TT7Max){%obj.client.quantity["bombrounds"] = $Pref::Server::TT7Max;}
	if (%obj.client.quantity["rocketrounds"] > $Pref::Server::TT8Max){%obj.client.quantity["rocketrounds"] = $Pref::Server::TT8Max;}
	if (%obj.client.quantity["boltrounds"] > $Pref::Server::TT9Max){%obj.client.quantity["boltrounds"] = $Pref::Server::TT9Max;}

	serverPlay3D(AmmoGetSound,%obj.getPosition());
	if(isObject(%col.spawnbrick))
	{
			%col.fadeOut();
			%col.schedule(%col.spawnbrick.itemrespawntime, "fadeIn");
			}else{
			%col.schedule(10, delete);
	}
	%this.onPickup(%obj, %player);
	return;
	}
	Parent::onCollision(%this, %obj, %col, %a, %b, %c, %d, %e, %f);
	}
};
activatePackage(BigAmmoDropPackage);