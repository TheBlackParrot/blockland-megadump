   datablock AudioProfile(ammogetSound)
   {
      filename = "./ammoget.wav";
      description = AudioClosest3d;
      preload = false;
   };

datablock ItemData(bigstaticItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system
	shapeFile = "./ammo_group.dts";
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;
	rotate = true;
	uiName = "Ammo Pile";
	doColorShift = false;
	colorShiftColor = "0.471 0.471 0.471 1.000";
	canDrop = true;
	ammocount = 4*2;
};

datablock ItemData(rocketstaticItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system
	shapeFile = "./ammo_rocket.dts";
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;
	rotate = true;
	uiName = "Ammo, Rocket";
	doColorShift = false;
	colorShiftColor = "0.471 0.471 0.471 1.000";
	canDrop = true;
	ammocount = 1;
};

function rocketstaticItem::onAdd(%this, %obj)
{
	if(%obj.ammocount == 0)
	{
	%obj.ammocount = %obj.getdatablock().ammocount;
	}
	%obj.rotate = true;
	%obj.setShapeName(%obj.ammocount);
	Parent::onAdd(%this, %obj);
}

/////////////////////////////////

datablock ItemData(grenadestaticItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system
	shapeFile = "./ammo_grenade.dts";
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;
	rotate = true;
	uiName = "Ammo, Grenade";
	doColorShift = false;
	colorShiftColor = "0.471 0.471 0.471 1.000";
	canDrop = true;
	ammocount = 1;
};

function grenadestaticItem::onAdd(%this, %obj)
{
	if(%obj.ammocount == 0)
	{
	%obj.ammocount = %obj.getdatablock().ammocount;
	}
	%obj.rotate = true;
	%obj.setShapeName(%obj.ammocount);
	Parent::onAdd(%this, %obj);
}

/////////////////////////////////

datablock ItemData(boltstaticItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system
	shapeFile = "./ammo_bolt.dts";
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;
	rotate = true;
	uiName = "Ammo, Bolt";
	doColorShift = false;
	colorShiftColor = "0.471 0.471 0.471 1.000";
	canDrop = true;
	ammocount = 1*6;
};

function boltstaticItem::onAdd(%this, %obj)
{
	if(%obj.ammocount == 0)
	{
	%obj.ammocount = %obj.getdatablock().ammocount;
	}
	%obj.rotate = true;
	%obj.setShapeName(%obj.ammocount);
	Parent::onAdd(%this, %obj);
}

/////////////////////////////////

datablock ItemData(threestaticItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system
	shapeFile = "./ammo_rifle.dts";
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;
	rotate = true;
	uiName = "Ammo, .270";
	doColorShift = false;
	colorShiftColor = "0.471 0.471 0.471 1.000";
	canDrop = true;
	ammocount = 4*2;
};

function threestaticItem::onAdd(%this, %obj)
{
	if(%obj.ammocount == 0)
	{
	%obj.ammocount = %obj.getdatablock().ammocount;
	}
	%obj.rotate = true;
	%obj.setShapeName(%obj.ammocount);
	Parent::onAdd(%this, %obj);
}

/////////////////////////////////
datablock ItemData(fivestaticItem : threestaticItem)
{
	shapeFile = "./ammo_556.dts";
	uiName = "Ammo, 5.56";
	ammocount = 15*3;
};

function fivestaticItem::onAdd(%this, %obj)
{
	if(%obj.ammocount == 0)
	{
	%obj.ammocount = %obj.getdatablock().ammocount;
	}
	%obj.rotate = true;
	%obj.setShapeName(%obj.ammocount);
	Parent::onAdd(%this, %obj);
}

/////////////////////////////////
datablock ItemData(sevenstaticItem : threestaticItem)
{
	shapeFile = "./ammo_708.dts";
	uiName = "Ammo, 7.08";
	ammocount = 24*2;
};

function sevenstaticItem::onAdd(%this, %obj)
{
	if(%obj.ammocount == 0)
	{
	%obj.ammocount = %obj.getdatablock().ammocount;
	}
	%obj.rotate = true;
	%obj.setShapeName(%obj.ammocount);
	Parent::onAdd(%this, %obj);
}

/////////////////////////////////
datablock ItemData(ShotgunStaticItem : threestaticItem)
{
	shapeFile = "./ammo_shotgun.dts";
	uiName = "Ammo, Buckshot";
	ammocount = 6*3;
};

function ShotgunStaticItem::onAdd(%this, %obj)
{
	if(%obj.ammocount == 0)
	{
	%obj.ammocount = %obj.getdatablock().ammocount;
	}
	%obj.rotate = true;
	%obj.setShapeName(%obj.ammocount);
	Parent::onAdd(%this, %obj);
}

/////////////////////////////////
datablock ItemData(ninestaticItem : threestaticItem)
{
	shapeFile = "./ammo_9MM.dts";
	uiName = "Ammo, 9mm";
	ammocount = 35*2;
};

function ninestaticItem::onAdd(%this, %obj)
{
	if(%obj.ammocount == 0)
	{
	%obj.ammocount = %obj.getdatablock().ammocount;
	}
	%obj.rotate = true;
	%obj.setShapeName(%obj.ammocount);
	Parent::onAdd(%this, %obj);
}

/////////////////////////////////
datablock ItemData(eightstaticItem : threestaticItem)
{
	shapeFile = "./ammo_MAGNUM.dts";
	uiName = "Ammo, .880M";
	ammocount = 6*2;
};

function eightstaticItem::onAdd(%this, %obj)
{
	if(%obj.ammocount == 0)
	{
	%obj.ammocount = %obj.getdatablock().ammocount;
	}

	%obj.rotate = true;
	%obj.setShapeName(%obj.ammocount);
	Parent::onAdd(%this, %obj);
}

/////////////////////////////////
package AmmoStaticPackage
{
	function Armor::onCollision(%this, %obj, %col, %a, %b, %c, %d, %e, %f)
	{
		if(%col.dataBlock $= "eightstaticItem" && %col.canPickup && %obj.getDamagePercent() < 1.0 && minigameCanUse(%obj.client, %col))
		{
		%obj.client.quantity["880rounds"] += %col.ammocount;
		if(%obj.client.quantity["880rounds"] > $Pref::Server::TT5Max)
			{
			%obj.client.quantity["880rounds"] = $Pref::Server::TT5Max;
		}
		serverPlay3D(AmmoGetSound,%obj.getPosition());

		if(isObject(%col.spawnbrick))
			{
			%col.fadeOut();
			%col.schedule(%col.spawnbrick.itemrespawntime, "fadeIn");
			}else{
			%col.schedule(10, delete);
			}
		%this.onPickup(%obj, %player);
		return;
	}
	Parent::onCollision(%this, %obj, %col, %a, %b, %c, %d, %e, %f);
	}
};
activatePackage(AmmoStaticPackage);

package AmmoStaticPackage2
{
	function Armor::onCollision(%this, %obj, %col, %a, %b, %c, %d, %e, %f)
	{
	if(%col.dataBlock $= "ninestaticItem" && %col.canPickup && %obj.getDamagePercent() < 1.0 && minigameCanUse(%obj.client, %col))
	{
	%obj.client.quantity["9mmrounds"] += %col.ammocount;
	if(%obj.client.quantity["9mmrounds"] > $Pref::Server::TT1Max)
	{
	%obj.client.quantity["9mmrounds"] = $Pref::Server::TT1Max;
	}
	serverPlay3D(AmmoGetSound,%obj.getPosition());
	if(isObject(%col.spawnbrick))
	{
			%col.fadeOut();
			%col.schedule(%col.spawnbrick.itemrespawntime, "fadeIn");
			}else{
			%col.schedule(10, delete);
	}
	%this.onPickup(%obj, %player);
	return;
	}
	Parent::onCollision(%this, %obj, %col, %a, %b, %c, %d, %e, %f);
	}
};
activatePackage(AmmoStaticPackage2);

package AmmoStaticPackage3
{
	function Armor::onCollision(%this, %obj, %col, %a, %b, %c, %d, %e, %f)
	{
	if(%col.dataBlock $= "shotgunStaticItem" && %col.canPickup && %obj.getDamagePercent() < 1.0 && minigameCanUse(%obj.client, %col))
	{
	%obj.client.quantity["shotgunrounds"] += %col.ammocount;
	if(%obj.client.quantity["shotgunrounds"] > $Pref::Server::TT3Max)
	{
	%obj.client.quantity["shotgunrounds"] = $Pref::Server::TT3Max;
	}
	serverPlay3D(AmmoGetSound,%obj.getPosition());
	if(isObject(%col.spawnbrick))
	{
			%col.fadeOut();
			%col.schedule(%col.spawnbrick.itemrespawntime, "fadeIn");
			}else{
			%col.schedule(10, delete);
	}
	%this.onPickup(%obj, %player);
	return;
	}
	Parent::onCollision(%this, %obj, %col, %a, %b, %c, %d, %e, %f);
	}
};
activatePackage(AmmoStaticPackage3);

package AmmoStaticPackage4
{
	function Armor::onCollision(%this, %obj, %col, %a, %b, %c, %d, %e, %f)
	{
	if(%col.dataBlock $= "threestaticItem" && %col.canPickup && %obj.getDamagePercent() < 1.0 && minigameCanUse(%obj.client, %col))
	{
	%obj.client.quantity["308rounds"] += %col.ammocount;
	if(%obj.client.quantity["308rounds"] > $Pref::Server::TT4Max)
	{
	%obj.client.quantity["308rounds"] =$Pref::Server::TT4Max;
	}
	serverPlay3D(AmmoGetSound,%obj.getPosition());
	if(isObject(%col.spawnbrick))
	{
			%col.fadeOut();
			%col.schedule(%col.spawnbrick.itemrespawntime, "fadeIn");
			}else{
			%col.schedule(10, delete);
	}
	%this.onPickup(%obj, %player);
	return;
	}
	Parent::onCollision(%this, %obj, %col, %a, %b, %c, %d, %e, %f);	
	}
};
activatePackage(AmmoStaticPackage4);

package AmmoStaticPackage5
{
	function Armor::onCollision(%this, %obj, %col, %a, %b, %c, %d, %e, %f)
	{
	if(%col.dataBlock $= "sevenstaticItem" && %col.canPickup && %obj.getDamagePercent() < 1.0 && minigameCanUse(%obj.client, %col))
	{
	%obj.client.quantity["708rounds"] += %col.ammocount;
	if(%obj.client.quantity["708rounds"] > $Pref::Server::TT8Max)
	{
	%obj.client.quantity["708rounds"] = $Pref::Server::TT8Max;
	}
	serverPlay3D(AmmoGetSound,%obj.getPosition());
	if(isObject(%col.spawnbrick))
	{
			%col.fadeOut();
			%col.schedule(%col.spawnbrick.itemrespawntime, "fadeIn");
			}else{
			%col.schedule(10, delete);
	}
	%this.onPickup(%obj, %player);
	return;
	}
	Parent::onCollision(%this, %obj, %col, %a, %b, %c, %d, %e, %f);	
	}
};
activatePackage(AmmoStaticPackage5);

package AmmoStaticPackage6
{
	function Armor::onCollision(%this, %obj, %col, %a, %b, %c, %d, %e, %f)
	{
	if(%col.dataBlock $= "fivestaticItem" && %col.canPickup && %obj.getDamagePercent() < 1.0 && minigameCanUse(%obj.client, %col))
	{
	%obj.client.quantity["556rounds"] += %col.ammocount;
	if(%obj.client.quantity["556rounds"] > $Pref::Server::TT2Max)
	{
	%obj.client.quantity["556rounds"] = $Pref::Server::TT2Max;
	}
	serverPlay3D(AmmoGetSound,%obj.getPosition());
	if(isObject(%col.spawnbrick))
	{
			%col.fadeOut();
			%col.schedule(%col.spawnbrick.itemrespawntime, "fadeIn");
			}else{
			%col.schedule(10, delete);
	}
	%this.onPickup(%obj, %player);
	return;
	}
	Parent::onCollision(%this, %obj, %col, %a, %b, %c, %d, %e, %f);
	}
};
activatePackage(AmmoStaticPackage6);

package AmmoStaticPackage7
{
	function Armor::onCollision(%this, %obj, %col, %a, %b, %c, %d, %e, %f)
	{
	if(%col.dataBlock $= "bigstaticItem" && %col.canPickup && %obj.getDamagePercent() < 1.0 && minigameCanUse(%obj.client, %col))
	{
   %obj.client.quantity["9MMrounds"] = $Pref::Server::TT1Max;
   %obj.client.quantity["556rounds"] = $Pref::Server::TT2Max;
   %obj.client.quantity["shotgunrounds"] = $Pref::Server::TT3Max;
   %obj.client.quantity["308rounds"] = $Pref::Server::TT4Max;
   %obj.client.quantity["708rounds"] = $Pref::Server::TT8Max;
   %obj.client.quantity["880rounds"] = $Pref::Server::TT5Max;
   %obj.client.quantity["boltrounds"] = $Pref::Server::TT9Max;
   %obj.client.quantity["bombrounds"] = $Pref::Server::TT6Max;
   %obj.client.quantity["rocketrounds"] = $Pref::Server::TT7Max; 
	serverPlay3D(AmmoGetSound,%obj.getPosition());
	if(isObject(%col.spawnbrick))
	{
			%col.fadeOut();
			%col.schedule(%col.spawnbrick.itemrespawntime, "fadeIn");
			}else{
			%col.schedule(10, delete);
	}
	%this.onPickup(%obj, %player);
	return;
	}
	Parent::onCollision(%this, %obj, %col, %a, %b, %c, %d, %e, %f);
	}
};
activatePackage(AmmoStaticPackage7);

package AmmoStaticPackage8
{
	function Armor::onCollision(%this, %obj, %col, %a, %b, %c, %d, %e, %f)
	{
	if(%col.dataBlock $= "boltstaticItem" && %col.canPickup && %obj.getDamagePercent() < 1.0 && minigameCanUse(%obj.client, %col))
	{
	%obj.client.quantity["boltrounds"] += %col.ammocount;
	if(%obj.client.quantity["boltrounds"] > $Pref::Server::TT9Max)
	{
	%obj.client.quantity["boltrounds"] = $Pref::Server::TT9Max;
	}
	serverPlay3D(AmmoGetSound,%obj.getPosition());
	if(isObject(%col.spawnbrick))
	{
			%col.fadeOut();
			%col.schedule(%col.spawnbrick.itemrespawntime, "fadeIn");
			}else{
			%col.schedule(10, delete);
	}
	%this.onPickup(%obj, %player);
	return;
	}
	Parent::onCollision(%this, %obj, %col, %a, %b, %c, %d, %e, %f);
	}
};
activatePackage(AmmoStaticPackage8);

package AmmoStaticPackage9
{
	function Armor::onCollision(%this, %obj, %col, %a, %b, %c, %d, %e, %f)
	{
	if(%col.dataBlock $= "grenadestaticItem" && %col.canPickup && %obj.getDamagePercent() < 1.0 && minigameCanUse(%obj.client, %col))
	{
	%obj.client.quantity["bombrounds"] += %col.ammocount;
	if(%obj.client.quantity["bombrounds"] > 14)
	{
	%obj.client.quantity["bombrounds"] = 14;
	}
	serverPlay3D(AmmoGetSound,%obj.getPosition());
	if(isObject(%col.spawnbrick))
	{
			%col.fadeOut();
			%col.schedule(%col.spawnbrick.itemrespawntime, "fadeIn");
			}else{
			%col.schedule(10, delete);
	}
	%this.onPickup(%obj, %player);
	return;
	}
	Parent::onCollision(%this, %obj, %col, %a, %b, %c, %d, %e, %f);
	}
};
activatePackage(AmmoStaticPackage9);

package AmmoStaticPackage10
{
	function Armor::onCollision(%this, %obj, %col, %a, %b, %c, %d, %e, %f)
	{
	if(%col.dataBlock $= "rocketstaticItem" && %col.canPickup && %obj.getDamagePercent() < 1.0 && minigameCanUse(%obj.client, %col))
	{
	%obj.client.quantity["rocketrounds"] += %col.ammocount;
	if(%obj.client.quantity["rocketrounds"] > 10)
	{
	%obj.client.quantity["rocketrounds"] = 10;
	}
	serverPlay3D(AmmoGetSound,%obj.getPosition());
	if(isObject(%col.spawnbrick))
	{
			%col.fadeOut();
			%col.schedule(%col.spawnbrick.itemrespawntime, "fadeIn");
			}else{
			%col.schedule(10, delete);
	}
	%this.onPickup(%obj, %player);
	return;
	}
	Parent::onCollision(%this, %obj, %col, %a, %b, %c, %d, %e, %f);
	}
};
activatePackage(AmmoStaticPackage10);
