//ammo system changer. 0 is T+T2 style, 1 is T+T style, 2 is bullet-hose classic blockland style
	RTB_registerPref("Ammo System","Tier+Tactical Ammo","$Pref::Server::TTAmmo","int 0 2","Script_GamePreferences",0,0,1);

//this forms the basis of tier+tactical's new ammo mod. just sayin'.
	RTB_registerPref("Drop Weapon Ammo","Tier+Tactical Ammo 1","$Pref::Server::TT1Drop","int 0 1","Script_GamePreferences",1,0,1);
	RTB_registerPref("Drop Grenade Ammo","Tier+Tactical Ammo 1","$Pref::Server::TT2Drop","int 0 1","Script_GamePreferences",1,0,1);

	RTB_registerPref("Starting Pistol Ammo","Tier+Tactical Ammo 2","$Pref::Server::TT1Ammo","int 0 280","Script_GamePreferences",35*4,0,1);
	RTB_registerPref("Starting Rifle Ammo","Tier+Tactical Ammo 2","$Pref::Server::TT2Ammo","int 0 180","Script_GamePreferences",15*6,0,1);
	RTB_registerPref("Starting Shotgun Ammo","Tier+Tactical Ammo 2","$Pref::Server::TT3Ammo","int 0 48","Script_GamePreferences",6*4,0,1);
	RTB_registerPref("Starting Sniper Ammo","Tier+Tactical Ammo 2","$Pref::Server::TT4Ammo","int 0 32","Script_GamePreferences",4*4,0,1);
	RTB_registerPref("Starting Magnum Ammo","Tier+Tactical Ammo 2","$Pref::Server::TT5Ammo","int 0 36","Script_GamePreferences",6*3,0,1);
	RTB_registerPref("Starting Grenade Ammo","Tier+Tactical Ammo 2","$Pref::Server::TT6Ammo","int 0 12","Script_GamePreferences",1*3,0,1);
	RTB_registerPref("Starting Rocket Ammo","Tier+Tactical Ammo 2","$Pref::Server::TT7Ammo","int 0 12","Script_GamePreferences",1*2,0,1);
	RTB_registerPref("Starting Big Rifle Ammo","Tier+Tactical Ammo 2","$Pref::Server::TT8Ammo","int 0 144","Script_GamePreferences",24*3,0,1);
	RTB_registerPref("Starting Bolt Ammo","Tier+Tactical Ammo 2","$Pref::Server::TT9Ammo","int 0 24","Script_GamePreferences",1*12,0,1);

	RTB_registerPref("Maximum Pistol Ammo","Tier+Tactical Ammo 3","$Pref::Server::TT1Max","int 1 560","Script_GamePreferences",280,0,1);
	RTB_registerPref("Maximum Rifle Ammo","Tier+Tactical Ammo 3","$Pref::Server::TT2Max","int 1 360","Script_GamePreferences",180,0,1);
	RTB_registerPref("Maximum Shotgun Ammo","Tier+Tactical Ammo 3","$Pref::Server::TT3Max","int 1 96","Script_GamePreferences",48,0,1);
	RTB_registerPref("Maximum Sniper Ammo","Tier+Tactical Ammo 3","$Pref::Server::TT4Max","int 1 64","Script_GamePreferences",32,0,1);
	RTB_registerPref("Maximum Magnum Ammo","Tier+Tactical Ammo 3","$Pref::Server::TT5Max","int 1 72","Script_GamePreferences",36,0,1);
	RTB_registerPref("Maximum Grenade Ammo","Tier+Tactical Ammo 3","$Pref::Server::TT6Max","int 1 24","Script_GamePreferences",12,0,1);
	RTB_registerPref("Maximum Rocket Ammo","Tier+Tactical Ammo 3","$Pref::Server::TT7Max","int 1 24","Script_GamePreferences",12,0,1);
	RTB_registerPref("Maximum Big Rifle Ammo","Tier+Tactical Ammo 3","$Pref::Server::TT8Max","int 1 288","Script_GamePreferences",144,0,1);
	RTB_registerPref("Maximum Bolt Ammo","Tier+Tactical Ammo 3","$Pref::Server::TT9Max","int 1 48","Script_GamePreferences",24,0,1);

function AmmoOnSpawn(%this,%obj)
{
   %obj.client.quantity["9MMrounds"] = $Pref::Server::TT1Ammo; //smg, pistol rounds
   %obj.client.quantity["556rounds"] = $Pref::Server::TT2Ammo; //various rifle rounds
   %obj.client.quantity["shotgunrounds"] = $Pref::Server::TT3Ammo; //combat shotgun, shotgun rounds
   %obj.client.quantity["308rounds"] = $Pref::Server::TT4Ammo; //mil. sniper rounds
   %obj.client.quantity["708rounds"] = $Pref::Server::TT8Ammo; //battle rifle rounds
   %obj.client.quantity["880rounds"] = $Pref::Server::TT5Ammo; //magnum rounds
   %obj.client.quantity["bombrounds"] = $Pref::Server::TT6Ammo; //grenade rounds
   %obj.client.quantity["rocketrounds"] = $Pref::Server::TT7Ammo; //rocket rounds
   %obj.client.quantity["boltrounds"] = $Pref::Server::TT9Ammo; //crossbow rounds
}

package AmmoSpawn
{
function armor::onadd(%this,%obj)
   {
      Parent::onadd(%this,%obj);
      AmmoOnSpawn(%this,%obj);
   }
};
activatePackage(AmmoSpawn);

//////////////////////////////////////////////////////

datablock AudioProfile(ReloadClick1Sound)
{
   filename    = "./reload_1.wav";
   description = AudioClose3d;
   preload = true;
};
datablock AudioProfile(ReloadClick2Sound)
{
   filename    = "./reload_2.wav";
   description = AudioClose3d;
   preload = true;
};
datablock AudioProfile(ReloadClick3Sound)
{
   filename    = "./reload_3.wav";
   description = AudioClose3d;
   preload = true;
};
datablock AudioProfile(ReloadClick4Sound)
{
   filename    = "./reload_4.wav";
   description = AudioClose3d;
   preload = true;
};
datablock AudioProfile(ReloadClick5Sound)
{
   filename    = "./reload_5.wav";
   description = AudioClose3d;
   preload = true;
};
datablock AudioProfile(ReloadClick6Sound)
{
   filename    = "./reload_6.wav";
   description = AudioClose3d;
   preload = true;
};
datablock AudioProfile(ReloadClick7Sound)
{
   filename    = "./reload_7.wav";
   description = AudioClose3d;
   preload = true;
};
datablock AudioProfile(ReloadClick8Sound)
{
   filename    = "./reload_8.wav";
   description = AudioClose3d;
   preload = true;
};

//we need the gun add-on for this, so force it to load
%error = ForceRequiredAddOn("Weapon_Gun");

if(%error == $Error::AddOn_Disabled)
{
   //we don't have the gun, so we're screwed
   error("ERROR: Weapon_Package_Tier1 - required add-on Weapon_Gun not found");
}
else
{
   exec("./Item_Ammo.cs");
   exec("./Ammo_Unified.cs");

   exec("./Support_RaycastingWeapons.cs");
   exec("./Support_AmmoGuns.cs");
   exec("./Weapon_Submachinegun.cs");  
   exec("./Weapon_Pump Shotgun.cs");
   exec("./Weapon_Pistol.cs"); 
   exec("./Weapon_Akimbo Pistol.cs"); 
   exec("./Weapon_Sport Rifle.cs"); 
}

datablock ExplosionData(TTLittleRecoilExplosion)
{
   explosionShape = "";

   lifeTimeMS = 150;

   faceViewer     = true;
   explosionScale = "1 1 1";

   shakeCamera = true;
  camShakeFreq = "1 1 1";
  camShakeAmp = "0.1 0.3 0.2";
   camShakeDuration = 0.5;
   camShakeRadius = 10.0;
};

datablock ProjectileData(TTLittleRecoilProjectile)
{
	lifetime						= 10;
	fadeDelay						= 10;
	explodeondeath						= true;
	explosion						= TTLittleRecoilExplosion;

};

datablock ExplosionData(TTRecoilExplosion)
{
   explosionShape = "";

   lifeTimeMS = 150;

   faceViewer     = true;
   explosionScale = "1 1 1";

   shakeCamera = true;
  camShakeFreq = "2 2 2";
  camShakeAmp = "0.3 0.5 0.4";
   camShakeDuration = 0.5;
   camShakeRadius = 10.0;
};

datablock ProjectileData(TTRecoilProjectile)
{
	lifetime						= 10;
	fadeDelay						= 10;
	explodeondeath						= true;
	explosion						= TTRecoilExplosion;

};

datablock ExplosionData(TTBigRecoilExplosion)
{
   explosionShape = "";

   lifeTimeMS = 150;

   faceViewer     = true;
   explosionScale = "1 1 1";

   shakeCamera = true;
  camShakeFreq = "3 3 3";
  camShakeAmp = "0.6 0.8 0.7";
   camShakeDuration = 0.5;
   camShakeRadius = 10.0;
};

datablock ProjectileData(TTBigRecoilProjectile)
{
	lifetime						= 10;
	fadeDelay						= 10;
	explodeondeath						= true;
	explosion						= TTBigRecoilExplosion;

};

datablock ExplosionData(TTHugeRecoilExplosion)
{
   explosionShape = "";

   lifeTimeMS = 150;

   faceViewer     = true;
   explosionScale = "1 1 1";

   shakeCamera = true;
  camShakeFreq = "5 5 5";
  camShakeAmp = "1.1 1.3 1.2";
   camShakeDuration = 0.5;
   camShakeRadius = 10.0;
};

datablock ProjectileData(TTHugeRecoilProjectile)
{
	lifetime						= 10;
	fadeDelay						= 10;
	explodeondeath						= true;
	explosion						= TTHugeRecoilExplosion;

};